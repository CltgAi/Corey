# Simple AI/BI Suite
A lightweight version.